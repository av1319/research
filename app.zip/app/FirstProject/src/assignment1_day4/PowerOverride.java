package assignment1_day4;

public class PowerOverride {

}
