package assignment1_day1;

public class Fibonacci {
	private static int a = 1 ;
	private static int b=1;
	private static int n=3;
 	private static float  sum=2;
	public void fiboSeries(int a,int b,int n,float sum){
		if (n==21)
			{  
			float average=sum/20;
			System.out.println("\nThe Average is "+average);
			}
		else{
		int temp;
		temp=a+b;
		sum+=temp;
		System.out.print(" "+temp+" ");
		n++;
		fiboSeries(b,temp,n,sum);
		}
		
		
	}
	public static void main(String[] args) {
		
Fibonacci fc= new Fibonacci();
System.out.print(a+"  "+b+" ");
fc.fiboSeries(a, b, n,sum);
	}

}
