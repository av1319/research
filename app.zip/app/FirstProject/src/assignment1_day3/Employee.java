package assignment1_day3;

import java.util.Scanner;

public class Employee {
	private String name;
	private double salary;
	public String getName() {
		return name;
	}
	
	public double getSalary() {
		return salary;
	}

	public Employee(String name, double salary) {
		this.name = name;
		this.salary = salary;
	}

	

}
class Manager extends Employee{
	
	private String department;
	
	public Manager(String name, double salary, String department) {
		super(name, salary);
		this.department =department;
	}

	public String toString(){

		return ("Manager name "+getName()+"\nManager Department "+department+"\nSalary "+getSalary());
	}
}

class Executive extends Manager{

	public Executive(String name, double salary, String department) {
		super(name, salary, department);
		
	}
	public String toString(){

		return("Executive "+super.toString());
	}
	
}

class TestEmployee{
	public static void main(String[] args) {
		
		Scanner s= new Scanner(System.in);
		String name;
		double salary;
		String department;
	
		
	
			System.out.println("Enter Name");
			name=s.next();

			System.out.println("Enter Salary");
			salary=s.nextDouble();

			System.out.println("Enter Department");
			department=s.next();
			
			
			
			
				
				Manager m= new Manager(name,salary,department);
				System.out.println(m.toString());
				
			
				Executive ex= new Executive(name,salary,department);
				System.out.println(ex.toString());
				
			
			
		
		
		s.close();
		
	}
}