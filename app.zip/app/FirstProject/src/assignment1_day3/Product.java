package assignment1_day3;
import java.util.*;
public class Product {
	private int productID;
	private String name; 
	private int categoryID;
	private double unitPrice;
	public Product(int productID, String name, int categoryID,
			double unitPrice) {
		super();
		this.productID = productID;
		this.name = name;
		this.categoryID = categoryID;
		this.unitPrice = unitPrice;
	}
	public int getProductID() {
		return productID;
	}
	
	public String getName() {
		return name;
	}
	
	public int getCategoryID() {
		return categoryID;
	}
	
	public double getUnitPrice() {
		return unitPrice;
	}
	
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
}

class ElectricalProduct extends Product{
	private String  voltageRange;
	private double wattage;
	public String getVoltageRange() {
		return voltageRange;
	}
	
	public double getWattage() {
		return wattage;
	}
	public void setWattage(double wattage) {
		this.wattage = wattage;
	}

	public ElectricalProduct(int productID, String name, int categoryID,
			double unitPrice, String voltageRange, double wattage) {
		super(productID, name, categoryID, unitPrice);
		this.voltageRange = voltageRange;
		this.wattage = wattage;
	}
	
public void display(){
		
		System.out.println("Product id "+getProductID()+"\nName "+getName()+"\nCategory id "+getCategoryID()+"\nPrice of electrical product "+getUnitPrice()+"\n Voltage range "+getVoltageRange()+"\nWattage "+getWattage());
	}
	
}


class TestProduct{
	
	public static void main(String[] args) {
		int productID;
		 String name; 
	    int categoryID;
		 double unitPrice;
		String voltageRange;
		double wattage;
		
		 int c;
			Scanner s= new Scanner(System.in);
			System.out.println("enter product id");
		     productID=s.nextInt();
			System.out.println("enter name");
			name=s.next(); 
			System.out.println("enter project id");
			categoryID=s.nextInt();
			System.out.println("enter Unit price");
			unitPrice=s.nextDouble(); 
		    System.out.println("enter Voltage range");
			voltageRange=s.next();
			System.out.println("enter wattage power");
			wattage=s.nextDouble();
			ElectricalProduct ep=null;
			do {
				 System.out.println("Enter 1 to display\n 2 to  modify Price of electrical product and wattage");
				 c=s.nextInt();
				 switch(c){
				 
				 case 1:
					 ep=new ElectricalProduct(productID, name ,categoryID,unitPrice,voltageRange,wattage);
					 ep.display();
					 break;
					 
				 case 2: 
					 System.out.println("Enter to modify Price of electrical product and wattage.");
					 unitPrice=s.nextDouble();
					 wattage=s.nextDouble();
					 ep.setUnitPrice(unitPrice);
					 ep.setWattage(wattage);
					 System.out.println("Your modified details are");
					 ep.display();
				 }
				
			} while (c==1||c==2);
			 s.close();
	}
	
	
}
