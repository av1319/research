package assignment1_day3;
import java.util.Scanner;
public class Vehicle {
	private int vehicleNo;
	private String model;
	private String manufacturer; 
	private String color;
	public Vehicle(int vehicleNo, String model, String manufacturer,String color) {
		
		this.vehicleNo = vehicleNo;
		this.model = model;
		this.manufacturer = manufacturer;
		this.color = color;
	}
	public int getVehicleNo() {
		return vehicleNo;
	}

	public String getModel() {
		return model;
	}
	
	public String getManufacturer() {
		return manufacturer;
	}
	
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	
	
	
	
}

class Truck extends Vehicle{
	private int loadingCapacity;

	public int getLoadingCapacity() {
		return loadingCapacity;
	}

	public void setLoadingCapacity(int loadingCapacity) {
		this.loadingCapacity = loadingCapacity;
	}

	public Truck(int vehicleNo, String model, String manufacturer,
			String color, int loadingCapacity) {
		super(vehicleNo, model, manufacturer, color);
		this.loadingCapacity = loadingCapacity;
	}
	
public void display(){
		
		System.out.println("Vehicle  no "+getVehicleNo()+"\nModel "+getModel()+"\nManufacturer "+getManufacturer()+"\nColor "+getColor()+"\nLoading Capacity of truck is "+getLoadingCapacity());
	}
	
}

class TestVehicle{
	
	public static void main(String[] args) {
		
		 int vehicleNo;
		 String model;
	     String manufacturer; 
		 String color;
		int loadingCapacity;
		
		int c;
		Scanner s= new Scanner(System.in);
		System.out.println("enter Vehicle number");
	    vehicleNo=s.nextInt();
		System.out.println("enter Model");
		model=s.next(); 
		System.out.println("enter manufacturer");
		manufacturer=s.next();
		System.out.println("enter  color");
		color=s.next(); 
	    System.out.println("enter Loading Capacity(in tons)");
		loadingCapacity=s.nextInt();
		
		Truck t= null;
		
		do {
			 System.out.println("Enter 1 to display\n2 to  modify Color  and Loading Capacity");
			 c=s.nextInt();
			 switch(c){
			 
			 case 1:
				 t=new Truck(vehicleNo,model,manufacturer,color,loadingCapacity);
				 t.display();
				 break;
				 
			 case 2: 
				 System.out.println("Enter to modify  Price  and periodical");
				 color=s.next();
				 loadingCapacity=s.nextInt();
				 t.setColor(color);
				 t.setLoadingCapacity(loadingCapacity);
				 System.out.println("Your modified details are");
				 t.display();
			 }
			
		} while (c==1||c==2);
		 s.close();
		
		
		
	}
}