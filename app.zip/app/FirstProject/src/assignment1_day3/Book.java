package assignment1_day3;

import java.util.Scanner;

public class Book {
private int id;
private String title;
private String author;
private double price;

public Book(int id, String title, String author, double price) {
	this.id = id;
	this.title = title;
	this.author = author;
	this.price = price;
}

public int getId() {
	return id;
}

public String getTitle() {
	return title;
}

public String getAuthor() {
	return author;
}

public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}

}

class Periodical extends Book{
	private String period;

	
	public Periodical(int id, String title, String author, double price,
			String period) {
		super(id, title, author, price);
		this.period = period;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}
	
public void display(){
		
		System.out.println("Book id "+getId()+"\n Book Title "+getTitle()+"\nAuthor "+getAuthor()+"\nPrice "+getPrice()+"\nPeriod "+getPeriod());
	}
	
	
}

class TestBook {
	public static void main(String[] args) {
		int id;
		String title;
		String author;
		double price;
		String period;
		
			int c;
			Scanner s= new Scanner(System.in);
			System.out.println("enter book id");
		    id=s.nextInt();
			System.out.println("enter book title");
			title=s.next(); 
			System.out.println("enter book author");
			author=s.next();
			System.out.println("enter  price");
			price=s.nextDouble(); 
		    System.out.println("enter Period(daily,weekly,monthly)");
			period=s.next();
			
			Periodical p=null;
			do {
				 System.out.println("Enter 1 to display\n 2 to  modify Price  and periodical");
				 c=s.nextInt();
				 switch(c){
				 
				 case 1:
					 p=new Periodical(id, title ,author,price,period);
					 p.display();
					 break;
					 
				 case 2: 
					 System.out.println("Enter to modify Price of electrical product and wattage.");
					 price=s.nextDouble();
					 period=s.next();
					 p.setPrice(price);
					 p.setPeriod(period);
					 System.out.println("Your modified details are");
					 p.display();
				 }
				
			} while (c==1||c==2);
			 s.close();
		
	}
}
