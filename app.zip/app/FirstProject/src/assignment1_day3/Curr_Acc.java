package assignment1_day3;

class Curr_acc extends Account
{
	public void checkBook(){
		
		
	}
	
public	boolean isMinBal(){
		boolean a=false;
		return a;
	}
public void serviceCharge(){
	
}
	
}