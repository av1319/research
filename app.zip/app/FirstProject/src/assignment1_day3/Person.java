package assignment1_day3;

import java.util.Scanner;

public class Person {
private String Name;
private int yearOfBirth;
public Person(String name, int yearOfBirth) {
	Name = name;
	this.yearOfBirth = yearOfBirth;
}
public String getName() {
	return Name;
}

public int getYearOfBirth() {
	return yearOfBirth;
}


}
class Student extends Person{
	private String major;

	public Student(String name,int year,String major) {
		super(name,year);
		this.major = major;
	}
	
	public void display(){
		System.out.println("Name "+super.getName()+"\nYear "+super.getYearOfBirth()+"\nMajor "+major);
	}
}

class Instructor extends Person{
	private double salary;
	
	public Instructor(String name,int year,Double salary){
		super(name,year);
		this.salary= salary;
	}
	
	public void display(){
		System.out.println("Name "+super.getName()+"\nYear "+super.getYearOfBirth()+"\nsalary "+salary);
	}
	
}

class TestPerson{
	public static void main(String[] args) {
		Scanner s= new Scanner(System.in);
		String name;
		int year;
		double salary;
		String major;
		int c;
		
		do {
		System.out.println("Enter 1 for Student \n2 for Instructor");
		c=s.nextInt();
		switch (c){
		case 1:
			System.out.println("Enter The Name ");
			name=s.next();
			System.out.println("Enter The Year of Birth ");
		     year=s.nextInt();
		     System.out.println("Enter Major");
		     major=s.next();
		     Student stu= new Student(name,year,major);
		     stu.display();
		     break;
		case 2: 
			System.out.println("Enter The Name ");
			name=s.next();
			System.out.println("Enter The Year of Birth ");
		     year=s.nextInt();
		     System.out.println("Enter Salary");
		     salary=s.nextDouble();
		     Instructor ins= new Instructor(name,year,salary);
		     ins.display();
		     break;
		case 0: 
			System.exit(1);
		     
			
		}
		
		}while(c==1 ||c ==2);
		s.close();
	}
}
