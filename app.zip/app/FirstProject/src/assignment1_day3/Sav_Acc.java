package assignment1_day3;

class Sav_acc extends Account{
public void compInterest(){
	
}
public void withdrawal(){
	
	
}
}
