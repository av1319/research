package assignment1_day3;

public class Account {
private String customerName;
private long accountNumber;
private String typeOfAccount;
private double Balance;

	
	
	public String getCustomerName() {
	return customerName;
}



public void setCustomerName(String customerName) {
	this.customerName = customerName;
}



public long getAccountNumber() {
	return accountNumber;
}



public void setAccountNumber(long accountNumber) {
	this.accountNumber = accountNumber;
}



public String getTypeOfAccount() {
	return typeOfAccount;
}



public void setTypeOfAccount(String typeOfAccount) {
	this.typeOfAccount = typeOfAccount;
}



public double getBalance() {
	return Balance;
}



public void setBalance(double balance) {
	Balance = balance;
}



	void balance(){
	
}
}



