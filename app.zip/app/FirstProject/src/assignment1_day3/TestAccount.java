package assignment1_day3;

import java.util.Scanner;

public class TestAccount {
public static void main(String[] args) {
	int choice;

	Scanner s = new Scanner(System.in);
	System.out.println("Enter 1 to Deposit\n2 to display balance\n3 toCompute and deposit Interest\n4 to withdraw \nCheck Minimum balance");
	 choice=s.nextInt();
}
}
