package assignment1_day2;
import java.util.*;

public class BookStoreApp {

	public static void main(String[] args) {
BookStore bookstore=new BookStore(10);
int n;
bookstore.init();
Scanner s= new Scanner (System.in);
do{
	
	System.out.println("press 1 to display 2 to order 3 to sell 0 to exit");
	
	n=s.nextInt();
	switch(n){
	case 1:
		bookstore.display();
		System.out.println("press any choice");
		break;
	case 2: 
	bookstore.order("ISBN 9",6);
	System.out.println("press any choice");
	break;
	case 3:
		bookstore.sell("Book 9",4);
		System.out.println("press any choice");
	case 0:
		break;
	}
}while (n!=0);

	}

}
