package pack1;
import java.util.*;

class Arrb{
	
	public float display(int arr[],int n){
		int sum=0;
		for(int i = 0; i < n; i++)
	    {
	       
	     sum+=arr[i];
	        
	    }
		return (sum/n);
	}
	
}

public class Arraypass {
	
	
	
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("");
	int n=sc.nextInt();
	
	int arr[] = new int[n];
	for(int i = 0; i < n; i++)
    {
        arr[i] = sc.nextInt();
    }
	Arrb ab = new Arrb();
	float avg=ab.display(arr,n);
	System.out.println("the average of array elements of size"+n+"is :"+avg);
	
}
}
