package pack1;

public class Firstclass {
	public String name,position;
	public int id;
	public Firstclass()
	{//Default constructor calls constructor with one parameter
		this(1);
		
	}
	public Firstclass(int id)
	{//This constructor calls constructor with two parameters
		this(id,"Akash");
		
	}
	public Firstclass(int id,String name)
	{//This constructor calls constructor with three parameters
	this(id,name,"Trainee")	;
	}
	public Firstclass(int id,String name,String position){
//this constructor initializes data member
		this.id=id;
		this.name=name;
		this.position=position;
		
	}
	protected void first(){
	System.out.println("Emp id= "+id);
	System.out.println("Emp Name= "+name);
	System.out.println("Emp position= "+position);

}
	public static void main(String[] args) {
		
		Firstclass fc= new Firstclass();
		fc.first();
		
	}
	
	public void first1(int id){
	System.out.println("My protected method"+id);

}

}
