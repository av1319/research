package pack1;
import java.util.*;
public class Getset {

private int stdid;
private String stdname;
public int getStdid() {//getter for id
	return stdid;
}
public void setStdid(int stdid) {//setter for id
	this.stdid = stdid;
}
public String getStdname() {//getter for name
	return stdname;
}
public void setStdname(String stdname) {//setter for name
	this.stdname = stdname;
}

}

class Mainclass{
	
	public static void main(String[] args) {
		Getset gt=new Getset();
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Student id and Stduent name");
		int id=sc.nextInt();
		String name=sc.next();
		
		gt.setStdid(id);
		gt.setStdname(name);
		
		int stdid=gt.getStdid();
		String stdname=gt.getStdname();
		
		System.out.println("The id is:"+stdid+"Name is"+stdname);
		
	}
}



