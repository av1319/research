package pack3;

import java.util.Scanner;

public class Rotate {
	Scanner s = new Scanner(System.in);
	public void rotate(int arr[],int r,int n){
		for (int i = 0; i < r; i++) {
		int temp=arr[n-1];
		for(int j=n-1;j>=1;j--){
			arr[j]=arr[j-1];
		   		}	
		arr[0]=temp;
		}
		for (int k = 0; k < n; k++) {
			System.out.print(arr[k]);			
		}
		
		System.out.println("\nenter the position of rotated array to display");
		int x=s.nextInt();
		System.out.println(arr[x-1]);
		
	}
	public static void main(String[] args) {
		int arr[] = { 1, 2, 3, 4, 5 };
		for (int i = 0; i < arr.length; i++) {
			int j = arr[i];
			System.out.print("  "+j);
}
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the number of rotations");
		int rotation = s.nextInt();
		int n=arr.length;
		Rotate  r= new Rotate();
		r.rotate(arr,rotation,n);
	}

}
