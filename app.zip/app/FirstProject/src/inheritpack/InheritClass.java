package inheritpack;

 class Account{

	/*public Account(int a,String b,float c)//Parent class constructor
	 * {
		System.out.println("This is Account Parent class and this is its constructor "+a);
	System.out.println(b+" "+c);
	}*/
	public static void Parent(String Bname,int pincode )//Static method of parent class
	{
		String Complete = Bname+" "+pincode;
		System.out.println("The complete information"+Complete);
	}
	
}
 
 class Savings extends Account{
	 
	/* public Savings(){//Child constructor
		 //super(10,"XYZ",22.22f);//PArent class constructor is invoked
		 System.out.println("Child class is savings And this is its constructor invoked");
	 }*/
	 
		public static void Parent(String Bname,int pincode )//Static method of inherit class
		{  //super.parent("UBI",232520);//static method of parent class is inherited but not overridden
			String Complete = Bname+" "+pincode;
			System.out.println("The complete information from the Child Class is: "+Complete);
		}
	 
 }
public class InheritClass {

	public static void main(String[] args) {
		
		Savings s= new Savings();
		s.Parent("SBI",202210);
		

	}

}
