package com.nucleus.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CreateConnection {
	Connection conn ;
	public Connection ConnectionClass() {
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@10.1.50.198:1521:orcl", "sh", "sh");
		} catch (ClassNotFoundException e1) {

			e1.printStackTrace();
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return conn;

	}
	public void closeConnection()
	{
	try {
		conn.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
	}

}
