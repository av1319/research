package com.nucleus.validation;

import java.sql.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.nucleus.connection.CreateConnection;


public class ValidationClass {
	Pattern pattern;
	Matcher matcher;
	CreateConnection createConnection = new CreateConnection();
	Connection conn = createConnection.ConnectionClass();
	public boolean fieldLengthValidation(Long pinCode) {
		if(pinCode.equals(" ")){
			return false;
		}
		else{
			String pCode = Long.toString(pinCode);
			if(pCode.length() == 6)
			{
				return true;
			}
			else
				return false;
		}
		
	}

	public boolean nullCheck(String attribute){
		if(attribute.equals("")){
			return false;
		}
		return true;

	}
	
	public boolean sizeValidate(int len,int length){
		
		if(len>length)
			{
			return false;
		
			}
			return true;		
	}
	public boolean recordStatusValidation(String recordStatus) {
		recordStatus = recordStatus.toUpperCase();
		if (recordStatus != null) {
			
			if (recordStatus.length() == 1
					&& (recordStatus.equals("N") || recordStatus.equals("M")
							|| recordStatus.equals("D")
							|| recordStatus.equals("A") || recordStatus
								.equals("R"))) {
				return true;
			} else {
				return false;
			}
		} 
		else
		{
			return false;
		}

	}

	public boolean flagValidation(String flag) {
		if (flag != null) {
			
			
			if (flag.length() == 1 && (flag.equals("A") || flag.equals("I"))) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	public boolean emailValidation(String email) {

		String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

		if (email.equals("")) {
			
			}
			if (String.valueOf(email).matches(EMAIL_PATTERN)) {
				return true;
			}
		
		return false;
	}

	public boolean customerNameValidation(String customerName) {

		if (customerName.equals(" ")) {
	return false;
	}
	else{
		
		char[] character1 = customerName.toCharArray();
			for (char c : character1) {

				if (!(Character.isLetterOrDigit(c))) {
					String ch = Character.toString(c);
					if (!ch.equals(" ")) {
						return false;
					}

				}
			}

			return true;

		}
	}
	
	
	public boolean isValidContactNumber(long string,int size){
		
		String strg = String.valueOf(string);
		if(strg!=null)
		{
			if(strg.length()<=size){
				char [] chars=strg.toCharArray();
				for (char c : chars) {
					if(Character.isDigit(c)){
						String ch= Character.toString(c);
						return true;
					}
					
				}
			}
		}
		return true;
	}
	
	public boolean checkPrimary_Key(String customerCode)
	{
	int count =0;
	PreparedStatement preparedStatement;
	try {
		preparedStatement = conn.prepareStatement("Select * from seql1234");
		ResultSet resultSet = preparedStatement.executeQuery();
		
		while(resultSet.next()){
			if(resultSet.getString(2).equals(customerCode)){
				count++;
			}
			
			
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	if(count ==0){
		return true;
	}else {
		return false;
	}
	}

	
}
