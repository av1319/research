package com.nucleus.dao;

import java.util.List;

import com.nucleus.domain.CustomerM;

//***********************Customer DATA OBJECT ACCESS INTERFACE**************

public interface CustomerDAO {
public void readFromFile(String location,int Rejection);

}
